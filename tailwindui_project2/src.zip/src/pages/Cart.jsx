import React from "react";
import Layout from "../components/common/Layout";

const Cart = () => {
    return (<Layout>
        <h1>Cart</h1>
    </Layout>);
}
export default Cart;