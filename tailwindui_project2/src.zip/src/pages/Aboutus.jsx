import React from "react";
import Layout from "../components/common/Layout";

const Aboutus = () => {
    return (
        <Layout>
            <h1>Aboutus</h1>
        </Layout>
    );
}
export default Aboutus;