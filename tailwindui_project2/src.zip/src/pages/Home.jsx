import React from "react";
import Layout from "../components/common/Layout";
import Header from "../components/header/Header";

const Home = () => {
    return (<>
        <Header />
            Home
    </>
    );
}

export default Home;
