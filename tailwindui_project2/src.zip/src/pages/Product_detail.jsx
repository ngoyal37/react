import React from "react";
import Layout from "../components/common/Layout";

const Productdetails = () => {
    return (<Layout>
        <h1>Productdetails</h1>
    </Layout>);
}
export default Productdetails;