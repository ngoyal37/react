import React from "react";
import Layout from "../components/common/Layout";

const Productlst = () => {
    return (<Layout>
        <h1>Productlst</h1>
    </Layout>);
}
export default Productlst;