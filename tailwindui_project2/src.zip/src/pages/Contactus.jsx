import React from "react";
import Layout from "../components/common/Layout";

const Contactus = () => {
    return (<Layout>
        <h1>Contactus</h1>
    </Layout>);
}
export default Contactus;