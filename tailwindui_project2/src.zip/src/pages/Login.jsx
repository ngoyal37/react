import React from "react";
import Layout from "../components/common/Layout";

const Login = () => {
    return (<Layout>
        <h1>Login</h1>
    </Layout>);
}
export default Login;