import React from "react";
import Layout from "../components/common/Layout";

const ViewProfile = () => {
    return (<Layout>
        <h1>ViewProfile</h1>
    </Layout>);
}
export default ViewProfile;