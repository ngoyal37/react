import React, { Suspense, Component } from 'react';

const PageLoader = () => {
    return <div className="pageloader">
        <h1>Page Loading....</h1>
    </div>;
}

export default PageLoader;
