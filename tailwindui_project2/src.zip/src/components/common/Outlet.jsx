import React, { Suspense, Component } from 'react';
import { Outlet } from "react-router-dom";

const Emptyoutlet = () => {
    return <Outlet />;
}

export default Emptyoutlet;
